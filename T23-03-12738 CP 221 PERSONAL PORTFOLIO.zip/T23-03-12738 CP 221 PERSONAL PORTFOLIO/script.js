
// Wait for the DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
  // Theme toggle functionality
  setupThemeToggle();
  
  // Dynamic greeting message
  displayGreeting();
  
  // Mobile menu toggle
  setupMobileMenu();
  
  // Portfolio filters
  setupPortfolioFilters();
  
  // Project detail toggles
  setupProjectDetailToggles();
  
  // Form validations
  setupFormValidations();
  
  // Image map tooltips
  setupImageMapTooltips();
});

// Theme Toggle Function
function setupThemeToggle() {
  const themeToggle = document.getElementById('theme-toggle');
  const toggleIcon = document.querySelector('.toggle-icon');
  
  if (!themeToggle || !toggleIcon) return;
  
  // Check for saved theme preference or use preferred color scheme
  const savedTheme = localStorage.getItem('theme');
  if (savedTheme === 'dark' || (!savedTheme && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
    document.body.classList.add('dark-mode');
    toggleIcon.textContent = '☀️';
  } else {
    toggleIcon.textContent = '🌙';
  }
  
  // Toggle theme on click
  themeToggle.addEventListener('click', function() {
    document.body.classList.toggle('dark-mode');
    const isDarkMode = document.body.classList.contains('dark-mode');
    toggleIcon.textContent = isDarkMode ? '☀️' : '🌙';
    localStorage.setItem('theme', isDarkMode ? 'dark' : 'light');
  });
}

// Greeting Function
function displayGreeting() {
  const greetingElement = document.getElementById('greeting-message');
  if (!greetingElement) return;
  
  const hour = new Date().getHours();
  let greeting;
  
  if (hour < 12) {
    greeting = "Good morning";
  } else if (hour < 18) {
    greeting = "Good afternoon";
  } else {
    greeting = "Good evening";
  }
  
  greetingElement.textContent = `${greeting}, welcome to my portfolio!`;
  
  // Add fade-in effect
  greetingElement.style.opacity = '0';
  setTimeout(() => {
    greetingElement.style.transition = 'opacity 1s ease-in-out';
    greetingElement.style.opacity = '1';
  }, 300);
}

// Mobile Menu Toggle Function
function setupMobileMenu() {
  const hamburger = document.querySelector('.hamburger');
  const navLinks = document.querySelector('.nav-links');
  
  if (!hamburger || !navLinks) return;
  
  hamburger.addEventListener('click', function() {
    navLinks.classList.toggle('active');
    hamburger.classList.toggle('active');
  });
  
  // Close menu when clicking on a link
  const links = navLinks.querySelectorAll('a');
  links.forEach(link => {
    link.addEventListener('click', function() {
      navLinks.classList.remove('active');
      hamburger.classList.remove('active');
    });
  });
  
  // Close menu when clicking outside
  document.addEventListener('click', function(event) {
    if (!hamburger.contains(event.target) && !navLinks.contains(event.target)) {
      navLinks.classList.remove('active');
      hamburger.classList.remove('active');
    }
  });
}

// Portfolio Filters Function
function setupPortfolioFilters() {
  const filterButtons = document.querySelectorAll('.filter-btn');
  const portfolioItems = document.querySelectorAll('.portfolio-item');
  
  if (filterButtons.length === 0 || portfolioItems.length === 0) return;
  
  filterButtons.forEach(button => {
    button.addEventListener('click', function() {
      // Update active button
      filterButtons.forEach(btn => btn.classList.remove('active'));
      this.classList.add('active');
      
      // Filter items
      const filterValue = this.getAttribute('data-filter');
      
      portfolioItems.forEach(item => {
        if (filterValue === 'all' || item.getAttribute('data-category') === filterValue) {
          item.style.display = 'block';
        } else {
          item.style.display = 'none';
        }
      });
    });
  });
}

// Project Detail Toggle Function
function setupProjectDetailToggles() {
  // Show detail buttons
  const showDetailButtons = document.querySelectorAll('.show-details-btn');
  if (!showDetailButtons) return;
  
  showDetailButtons.forEach(button => {
    button.addEventListener('click', function() {
      const projectId = this.getAttribute('data-project');
      const detailsElement = document.getElementById(`project-${projectId}-details`);
      
      if (detailsElement) {
        detailsElement.style.display = 'block';
        this.style.display = 'none';
      }
    });
  });
  
  // Hide detail buttons
  const hideDetailButtons = document.querySelectorAll('.hide-details-btn');
  if (!hideDetailButtons) return;
  
  hideDetailButtons.forEach(button => {
    button.addEventListener('click', function() {
      const detailsElement = this.closest('.portfolio-details');
      const projectInfo = detailsElement.previousElementSibling;
      const showButton = projectInfo.querySelector('.show-details-btn');
      
      if (detailsElement && showButton) {
        detailsElement.style.display = 'none';
        showButton.style.display = 'inline-block';
      }
    });
  });
}

// Form Validation Function
function setupFormValidations() {
  // Contact form validation
  const contactForm = document.getElementById('contactForm');
  if (!contactForm) return;
  
  contactForm.addEventListener('submit', function(event) {
    event.preventDefault();
    
    let isValid = true;
    
    // Validate name
    const nameInput = document.getElementById('name');
    const nameError = document.getElementById('name-error');
    if (nameInput && nameError) {
      if (nameInput.value.trim() === '') {
        showError(nameInput, nameError, 'Please enter your name');
        isValid = false;
      } else {
        hideError(nameInput, nameError);
      }
    }
    
    // Validate email
    const emailInput = document.getElementById('email');
    const emailError = document.getElementById('email-error');
    if (emailInput && emailError) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(emailInput.value)) {
        showError(emailInput, emailError, 'Please enter a valid email address');
        isValid = false;
      } else {
        hideError(emailInput, emailError);
      }
    }
    
    // Validate phone (if provided)
    const phoneInput = document.getElementById('phone');
    const phoneError = document.getElementById('phone-error');
    if (phoneInput && phoneError && phoneInput.value.trim() !== '') {
      const phoneRegex = /^(\+\d{1,3})?\s?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}$/;
      if (!phoneRegex.test(phoneInput.value)) {
        showError(phoneInput, phoneError, 'Please enter a valid phone number');
        isValid = false;
      } else {
        hideError(phoneInput, phoneError);
      }
    }
    
    // Validate message
    const messageInput = document.getElementById('message');
    const messageError = document.getElementById('message-error');
    if (messageInput && messageError) {
      if (messageInput.value.trim() === '') {
        showError(messageInput, messageError, 'Please enter your message');
        isValid = false;
      } else {
        hideError(messageInput, messageError);
      }
    }
    
    // If form is valid, show success message
    if (isValid) {
      const successMessage = document.getElementById('success-message');
      if (successMessage) {
        successMessage.classList.remove('hidden');
        contactForm.reset();
        
        // Close success message when clicking close button
        const closeButton = successMessage.querySelector('.close-message');
        if (closeButton) {
          closeButton.addEventListener('click', function() {
            successMessage.classList.add('hidden');
          });
        }
        
        // Automatically hide the message after 5 seconds
        setTimeout(function() {
          successMessage.classList.add('hidden');
        }, 5000);
      }
    }
  });
  
  // Survey form validation (if exists)
  const surveyForm = document.getElementById('surveyForm');
  if (surveyForm) {
    surveyForm.addEventListener('submit', function(event) {
      event.preventDefault();
      
      let isValid = true;
      let checkedCount = 0;
      
      // Check required inputs
      const requiredInputs = surveyForm.querySelectorAll('[required]');
      requiredInputs.forEach(input => {
        if (input.value.trim() === '') {
          input.classList.add('error');
          isValid = false;
        } else {
          input.classList.remove('error');
        }
      });
      
      // Validate checkboxes (at least one must be checked)
      const checkboxes = surveyForm.querySelectorAll('input[type="checkbox"]');
      checkboxes.forEach(checkbox => {
        if (checkbox.checked) {
          checkedCount++;
        }
      });
      
      if (checkedCount === 0) {
        const checkboxError = document.getElementById('checkbox-error');
        if (checkboxError) {
          checkboxError.textContent = 'Please select at least one option';
          checkboxError.style.display = 'block';
        }
        isValid = false;
      } else {
        const checkboxError = document.getElementById('checkbox-error');
        if (checkboxError) {
          checkboxError.style.display = 'none';
        }
      }
      
      if (isValid) {
        // Show success message
        alert('Thank you for completing the survey!');
        surveyForm.reset();
      }
    });
  }
}

// Helper function to show error message
function showError(inputElement, errorElement, message) {
  inputElement.classList.add('error');
  errorElement.textContent = message;
  errorElement.style.display = 'block';
}

// Helper function to hide error message
function hideError(inputElement, errorElement) {
  inputElement.classList.remove('error');
  errorElement.style.display = 'none';
}

// Image Map Tooltips
function setupImageMapTooltips() {
  const tooltip = document.getElementById('tooltip');
  if (!tooltip) return;
  
  const areas = document.querySelectorAll('area');
  areas.forEach(area => {
    area.addEventListener('mouseover', function(e) {
      const title = this.getAttribute('title');
      if (title) {
        tooltip.textContent = title;
        tooltip.style.display = 'block';
        tooltip.style.left = e.pageX + 10 + 'px';
        tooltip.style.top = e.pageY + 10 + 'px';
      }
    });
    
    area.addEventListener('mousemove', function(e) {
      tooltip.style.left = e.pageX + 10 + 'px';
      tooltip.style.top = e.pageY + 10 + 'px';
    });
    
    area.addEventListener('mouseout', function() {
      tooltip.style.display = 'none';
    });
    
    area.addEventListener('click', function(e) {
      e.preventDefault();
      const sectionId = this.getAttribute('href');
      const title = this.getAttribute('title');
      alert(`You clicked on ${title}`);
    });
  });
}
